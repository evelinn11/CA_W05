﻿namespace Class_Assignment_W05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGV_Tim = new System.Windows.Forms.DataGridView();
            this.lb_TimID = new System.Windows.Forms.Label();
            this.lb_NamaTim = new System.Windows.Forms.Label();
            this.lb_NamaStadium = new System.Windows.Forms.Label();
            this.lb_Kapasitas = new System.Windows.Forms.Label();
            this.lb_Kota = new System.Windows.Forms.Label();
            this.lb_NamaManager = new System.Windows.Forms.Label();
            this.tB_TimID = new System.Windows.Forms.TextBox();
            this.tB_NamaTim = new System.Windows.Forms.TextBox();
            this.tB_NamaStadium = new System.Windows.Forms.TextBox();
            this.tB_Kapasitas = new System.Windows.Forms.TextBox();
            this.tB_Kota = new System.Windows.Forms.TextBox();
            this.tB_NamaManager = new System.Windows.Forms.TextBox();
            this.btn_Input = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Tim)).BeginInit();
            this.SuspendLayout();
            // 
            // dGV_Tim
            // 
            this.dGV_Tim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_Tim.Location = new System.Drawing.Point(18, 335);
            this.dGV_Tim.Name = "dGV_Tim";
            this.dGV_Tim.RowHeadersWidth = 82;
            this.dGV_Tim.RowTemplate.Height = 33;
            this.dGV_Tim.Size = new System.Drawing.Size(1698, 607);
            this.dGV_Tim.TabIndex = 0;
            // 
            // lb_TimID
            // 
            this.lb_TimID.AutoSize = true;
            this.lb_TimID.Location = new System.Drawing.Point(54, 42);
            this.lb_TimID.Name = "lb_TimID";
            this.lb_TimID.Size = new System.Drawing.Size(73, 25);
            this.lb_TimID.TabIndex = 1;
            this.lb_TimID.Text = "Tim ID";
            // 
            // lb_NamaTim
            // 
            this.lb_NamaTim.AutoSize = true;
            this.lb_NamaTim.Location = new System.Drawing.Point(54, 79);
            this.lb_NamaTim.Name = "lb_NamaTim";
            this.lb_NamaTim.Size = new System.Drawing.Size(109, 25);
            this.lb_NamaTim.TabIndex = 2;
            this.lb_NamaTim.Text = "Nama Tim";
            // 
            // lb_NamaStadium
            // 
            this.lb_NamaStadium.AutoSize = true;
            this.lb_NamaStadium.Location = new System.Drawing.Point(54, 119);
            this.lb_NamaStadium.Name = "lb_NamaStadium";
            this.lb_NamaStadium.Size = new System.Drawing.Size(152, 25);
            this.lb_NamaStadium.TabIndex = 3;
            this.lb_NamaStadium.Text = "Nama Stadium";
            // 
            // lb_Kapasitas
            // 
            this.lb_Kapasitas.AutoSize = true;
            this.lb_Kapasitas.Location = new System.Drawing.Point(54, 156);
            this.lb_Kapasitas.Name = "lb_Kapasitas";
            this.lb_Kapasitas.Size = new System.Drawing.Size(107, 25);
            this.lb_Kapasitas.TabIndex = 4;
            this.lb_Kapasitas.Text = "Kapasitas";
            // 
            // lb_Kota
            // 
            this.lb_Kota.AutoSize = true;
            this.lb_Kota.Location = new System.Drawing.Point(54, 193);
            this.lb_Kota.Name = "lb_Kota";
            this.lb_Kota.Size = new System.Drawing.Size(56, 25);
            this.lb_Kota.TabIndex = 5;
            this.lb_Kota.Text = "Kota";
            // 
            // lb_NamaManager
            // 
            this.lb_NamaManager.AutoSize = true;
            this.lb_NamaManager.Location = new System.Drawing.Point(54, 230);
            this.lb_NamaManager.Name = "lb_NamaManager";
            this.lb_NamaManager.Size = new System.Drawing.Size(159, 25);
            this.lb_NamaManager.TabIndex = 6;
            this.lb_NamaManager.Text = "Nama Manager";
            // 
            // tB_TimID
            // 
            this.tB_TimID.Enabled = false;
            this.tB_TimID.Location = new System.Drawing.Point(218, 42);
            this.tB_TimID.Name = "tB_TimID";
            this.tB_TimID.Size = new System.Drawing.Size(214, 31);
            this.tB_TimID.TabIndex = 7;
            // 
            // tB_NamaTim
            // 
            this.tB_NamaTim.Location = new System.Drawing.Point(218, 79);
            this.tB_NamaTim.Name = "tB_NamaTim";
            this.tB_NamaTim.Size = new System.Drawing.Size(214, 31);
            this.tB_NamaTim.TabIndex = 8;
            this.tB_NamaTim.TextChanged += new System.EventHandler(this.tB_NamaTim_TextChanged);
            // 
            // tB_NamaStadium
            // 
            this.tB_NamaStadium.Location = new System.Drawing.Point(218, 116);
            this.tB_NamaStadium.Name = "tB_NamaStadium";
            this.tB_NamaStadium.Size = new System.Drawing.Size(214, 31);
            this.tB_NamaStadium.TabIndex = 9;
            // 
            // tB_Kapasitas
            // 
            this.tB_Kapasitas.Location = new System.Drawing.Point(218, 153);
            this.tB_Kapasitas.Name = "tB_Kapasitas";
            this.tB_Kapasitas.Size = new System.Drawing.Size(214, 31);
            this.tB_Kapasitas.TabIndex = 10;
            // 
            // tB_Kota
            // 
            this.tB_Kota.Location = new System.Drawing.Point(218, 190);
            this.tB_Kota.Name = "tB_Kota";
            this.tB_Kota.Size = new System.Drawing.Size(214, 31);
            this.tB_Kota.TabIndex = 11;
            // 
            // tB_NamaManager
            // 
            this.tB_NamaManager.Location = new System.Drawing.Point(218, 227);
            this.tB_NamaManager.Name = "tB_NamaManager";
            this.tB_NamaManager.Size = new System.Drawing.Size(214, 31);
            this.tB_NamaManager.TabIndex = 12;
            // 
            // btn_Input
            // 
            this.btn_Input.Location = new System.Drawing.Point(142, 278);
            this.btn_Input.Name = "btn_Input";
            this.btn_Input.Size = new System.Drawing.Size(148, 51);
            this.btn_Input.TabIndex = 13;
            this.btn_Input.Text = "Input";
            this.btn_Input.UseVisualStyleBackColor = true;
            this.btn_Input.Click += new System.EventHandler(this.btn_Input_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1733, 954);
            this.Controls.Add(this.btn_Input);
            this.Controls.Add(this.tB_NamaManager);
            this.Controls.Add(this.tB_Kota);
            this.Controls.Add(this.tB_Kapasitas);
            this.Controls.Add(this.tB_NamaStadium);
            this.Controls.Add(this.tB_NamaTim);
            this.Controls.Add(this.tB_TimID);
            this.Controls.Add(this.lb_NamaManager);
            this.Controls.Add(this.lb_Kota);
            this.Controls.Add(this.lb_Kapasitas);
            this.Controls.Add(this.lb_NamaStadium);
            this.Controls.Add(this.lb_NamaTim);
            this.Controls.Add(this.lb_TimID);
            this.Controls.Add(this.dGV_Tim);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Tim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGV_Tim;
        private System.Windows.Forms.Label lb_TimID;
        private System.Windows.Forms.Label lb_NamaTim;
        private System.Windows.Forms.Label lb_NamaStadium;
        private System.Windows.Forms.Label lb_Kapasitas;
        private System.Windows.Forms.Label lb_Kota;
        private System.Windows.Forms.Label lb_NamaManager;
        private System.Windows.Forms.TextBox tB_TimID;
        private System.Windows.Forms.TextBox tB_NamaTim;
        private System.Windows.Forms.TextBox tB_NamaStadium;
        private System.Windows.Forms.TextBox tB_Kapasitas;
        private System.Windows.Forms.TextBox tB_Kota;
        private System.Windows.Forms.TextBox tB_NamaManager;
        private System.Windows.Forms.Button btn_Input;
    }
}

